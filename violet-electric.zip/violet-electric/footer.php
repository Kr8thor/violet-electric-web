<footer class="w-full py-8 bg-gray-900 text-gray-200 mt-12">
    <div class="container mx-auto text-center">
        <p>&copy; <?php echo date('Y'); ?> Violet Electric. All rights reserved.</p>
    </div>
    <?php wp_footer(); ?>
</footer>
</body>
</html> 